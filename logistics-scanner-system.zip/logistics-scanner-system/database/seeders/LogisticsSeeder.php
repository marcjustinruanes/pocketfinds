<?php
namespace Database\Seeders;
use App\Models\Area;
use App\Models\Parcel;
use App\Models\Rider;
use App\Models\ParcelEvent;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Hash;

class LogisticsSeeder extends Seeder
{
    public function run(): void
    {
        $user = DB::table('users')->where('email', 'logistics@example.com')->first();
        if (!$user) {
            DB::table('users')->insert(['name'=>'Logistics Staff','email'=>'logistics@example.com','password'=>Hash::make('password'),'created_at'=>now(),'updated_at'=>now()]);
            $user = DB::table('users')->where('email', 'logistics@example.com')->first();
        }
        $areas = [
            ['name'=>'Area A','city_keywords'=>'santa cruz'],
            ['name'=>'Area B','city_keywords'=>'pagsanjan'],
            ['name'=>'Area C','city_keywords'=>'los baños,los banos'],
        ];
        foreach ($areas as $row) Area::updateOrCreate(['name'=>$row['name']], $row);
        $areaA = Area::where('name','Area A')->first(); $areaB = Area::where('name','Area B')->first(); $areaC = Area::where('name','Area C')->first();
        Rider::updateOrCreate(['name'=>'Rider 01'], ['contact'=>'09170000001','area_id'=>$areaA->id,'active'=>true]);
        Rider::updateOrCreate(['name'=>'Rider 02'], ['contact'=>'09170000002','area_id'=>$areaB->id,'active'=>true]);
        Rider::updateOrCreate(['name'=>'Rider 03'], ['contact'=>'09170000003','area_id'=>$areaC->id,'active'=>true]);
        $samples = [
            ['tracking_number'=>'TRK-2026-0001','sender_name'=>'Juan Dela Cruz','receiver_name'=>'Maria Santos','receiver_contact'=>'09171234567','delivery_address'=>'Brgy. Poblacion','delivery_city'=>'Santa Cruz, Laguna'],
            ['tracking_number'=>'TRK-2026-0002','sender_name'=>'Ana Reyes','receiver_name'=>'Pedro Garcia','receiver_contact'=>'09179876543','delivery_address'=>'Brgy. Sampaloc','delivery_city'=>'Pagsanjan, Laguna'],
            ['tracking_number'=>'TRK-2026-0003','sender_name'=>'LSPU Store','receiver_name'=>'Mark Villanueva','receiver_contact'=>'09175555555','delivery_address'=>'Brgy. Batong Malake','delivery_city'=>'Los Baños, Laguna'],
        ];
        foreach ($samples as $row) {
            $parcel = Parcel::updateOrCreate(['tracking_number'=>$row['tracking_number']], $row);
            ParcelEvent::firstOrCreate(['parcel_id'=>$parcel->id,'status'=>'Pending'], ['note'=>'Delivery request created.','created_by'=>$user->id]);
        }
    }
}
