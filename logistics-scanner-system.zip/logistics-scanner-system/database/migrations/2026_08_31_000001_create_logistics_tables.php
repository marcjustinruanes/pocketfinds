<?php
use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    public function up(): void {
        Schema::create('areas', function (Blueprint $table) {
            $table->id(); $table->string('name')->unique(); $table->text('city_keywords')->nullable(); $table->timestamps();
        });
        Schema::create('riders', function (Blueprint $table) {
            $table->id(); $table->string('name'); $table->string('contact')->nullable(); $table->foreignId('area_id')->constrained()->cascadeOnUpdate()->restrictOnDelete(); $table->boolean('active')->default(true); $table->timestamps();
        });
        Schema::create('parcels', function (Blueprint $table) {
            $table->id(); $table->string('tracking_number')->unique(); $table->string('sender_name'); $table->string('receiver_name'); $table->string('receiver_contact')->nullable(); $table->text('delivery_address'); $table->string('delivery_city'); $table->foreignId('area_id')->nullable()->constrained()->nullOnDelete(); $table->enum('status', ['Pending','Received','Sorted','Assigned','Picked Up','In Transit','Delivered','Failed/Issue'])->default('Pending'); $table->timestamp('received_at')->nullable(); $table->timestamp('sorted_at')->nullable(); $table->timestamp('assigned_at')->nullable(); $table->timestamp('picked_up_at')->nullable(); $table->timestamp('delivered_at')->nullable(); $table->text('issue_note')->nullable(); $table->timestamps();
        });
        Schema::create('parcel_assignments', function (Blueprint $table) {
            $table->id(); $table->foreignId('parcel_id')->unique()->constrained()->cascadeOnDelete(); $table->foreignId('rider_id')->constrained()->cascadeOnUpdate()->restrictOnDelete(); $table->unsignedBigInteger('assigned_by')->nullable(); $table->timestamp('assigned_at')->nullable(); $table->timestamps();
        });
        Schema::create('parcel_events', function (Blueprint $table) {
            $table->id(); $table->foreignId('parcel_id')->constrained()->cascadeOnDelete(); $table->string('status'); $table->text('note')->nullable(); $table->unsignedBigInteger('created_by')->nullable(); $table->timestamps();
        });
    }
    public function down(): void { Schema::dropIfExists('parcel_events'); Schema::dropIfExists('parcel_assignments'); Schema::dropIfExists('parcels'); Schema::dropIfExists('riders'); Schema::dropIfExists('areas'); }
};
