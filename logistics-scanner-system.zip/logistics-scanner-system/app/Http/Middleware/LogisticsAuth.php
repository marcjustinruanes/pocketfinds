<?php

namespace App\Http\Middleware;

use Closure;
use Illuminate\Http\Request;
use Symfony\Component\HttpFoundation\Response;

class LogisticsAuth
{
    public function handle(Request $request, Closure $next): Response
    {
        if (!$request->session()->has('logistics_user_id')) {
            return redirect()->route('login');
        }

        return $next($request);
    }
}
