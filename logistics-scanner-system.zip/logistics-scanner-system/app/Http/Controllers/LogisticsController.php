<?php

namespace App\Http\Controllers;

use App\Models\Area;
use App\Models\Parcel;
use App\Models\ParcelAssignment;
use App\Models\ParcelEvent;
use App\Models\Rider;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Hash;

class LogisticsController extends Controller
{
    public function showLogin() { return view('auth.login'); }

    public function login(Request $request)
    {
        $data = $request->validate(['email' => 'required|email', 'password' => 'required']);
        $user = DB::table('users')->where('email', $data['email'])->first();
        if (!$user || !Hash::check($data['password'], $user->password)) {
            return back()->withErrors(['email' => 'Invalid logistics account.'])->withInput();
        }
        $request->session()->regenerate();
        $request->session()->put('logistics_user_id', $user->id);
        $request->session()->put('logistics_user_name', $user->name);
        return redirect()->route('logistics.dashboard');
    }

    public function logout(Request $request)
    {
        $request->session()->forget(['logistics_user_id', 'logistics_user_name']);
        $request->session()->invalidate();
        $request->session()->regenerateToken();
        return redirect()->route('login');
    }

    public function dashboard()
    {
        $counts = [
            'pending' => Parcel::whereIn('status', ['Pending', 'Received'])->count(),
            'sorted' => Parcel::where('status', 'Sorted')->count(),
            'assigned' => Parcel::where('status', 'Assigned')->count(),
            'transit' => Parcel::where('status', 'In Transit')->count(),
            'delivered' => Parcel::where('status', 'Delivered')->count(),
            'issues' => Parcel::where('status', 'Failed/Issue')->count(),
        ];
        $recent = Parcel::with(['area', 'assignment.rider'])->latest()->limit(8)->get();
        return view('logistics.dashboard', compact('counts', 'recent'));
    }

    public function scan() { return view('logistics.scan'); }

    public function lookup(Request $request)
    {
        $data = $request->validate(['tracking_number' => 'required|string|max:100']);
        $tracking = trim($data['tracking_number']);
        $parcel = Parcel::with(['area', 'assignment.rider'])->where('tracking_number', $tracking)->first();
        if (!$parcel) return response()->json(['ok' => false, 'message' => 'Parcel not found. Check the tracking number.'], 404);
        return response()->json(['ok' => true, 'parcel' => $this->parcelPayload($parcel)]);
    }

    public function receive(Parcel $parcel)
    {
        if ($parcel->status === 'Pending') {
            $parcel->update(['status' => 'Received', 'received_at' => now()]);
            $this->event($parcel, 'Received', 'Parcel received at logistics center.');
        }
        return back()->with('success', 'Parcel marked as received.');
    }

    public function sort(Parcel $parcel)
    {
        $area = $this->determineArea($parcel);
        $parcel->update(['area_id' => $area->id, 'status' => 'Sorted', 'sorted_at' => now()]);
        $this->event($parcel, 'Sorted', 'Sorted to '.$area->name.'.');
        return back()->with('success', 'Parcel sorted to '.$area->name.'.');
    }

    public function assign(Request $request, Parcel $parcel)
    {
        $data = $request->validate(['rider_id' => 'required|exists:riders,id']);
        $rider = Rider::with('area')->findOrFail($data['rider_id']);
        if (!$parcel->area_id || $rider->area_id !== $parcel->area_id) {
            return back()->withErrors(['rider_id' => 'This rider is not assigned to the parcel delivery area.']);
        }
        ParcelAssignment::updateOrCreate(
            ['parcel_id' => $parcel->id],
            ['rider_id' => $rider->id, 'assigned_by' => session('logistics_user_id'), 'assigned_at' => now()]
        );
        $parcel->update(['status' => 'Assigned', 'assigned_at' => now()]);
        $this->event($parcel, 'Assigned', 'Assigned to '.$rider->name.'.');
        return back()->with('success', 'Parcel assigned to '.$rider->name.'.');
    }

    public function status(Request $request, Parcel $parcel)
    {
        $data = $request->validate(['status' => 'required|in:Picked Up,In Transit,Delivered,Failed/Issue', 'issue_note' => 'nullable|string|max:1000']);
        $updates = ['status' => $data['status']];
        if ($data['status'] === 'Picked Up') $updates['picked_up_at'] = now();
        if ($data['status'] === 'Delivered') $updates['delivered_at'] = now();
        if ($data['status'] === 'Failed/Issue') $updates['issue_note'] = $data['issue_note'] ?? null;
        $parcel->update($updates);
        $this->event($parcel, $data['status'], $data['issue_note'] ?? null);
        return back()->with('success', 'Parcel status updated.');
    }

    public function parcels() { $parcels = Parcel::with(['area', 'assignment.rider'])->latest()->paginate(15); return view('logistics.parcels', compact('parcels')); }
    public function history() { $events = ParcelEvent::with('parcel')->latest()->paginate(30); return view('logistics.history', compact('events')); }
    public function issues() { $parcels = Parcel::where('status', 'Failed/Issue')->latest()->paginate(15); return view('logistics.issues', compact('parcels')); }
    public function messages() { return view('logistics.messages'); }

    private function event(Parcel $parcel, string $status, ?string $note = null): void
    {
        ParcelEvent::create(['parcel_id' => $parcel->id, 'status' => $status, 'note' => $note, 'created_by' => session('logistics_user_id')]);
    }

    private function determineArea(Parcel $parcel): Area
    {
        $text = strtolower($parcel->delivery_address.' '.$parcel->delivery_city);
        foreach (Area::all() as $area) {
            foreach (preg_split('/\s*,\s*/', strtolower($area->city_keywords)) as $keyword) {
                if ($keyword !== '' && str_contains($text, trim($keyword))) return $area;
            }
        }
        return Area::firstOrCreate(['name' => 'Unassigned Area'], ['city_keywords' => '']);
    }

    private function parcelPayload(Parcel $parcel): array
    {
        return [
            'id' => $parcel->id,
            'tracking_number' => $parcel->tracking_number,
            'sender_name' => $parcel->sender_name,
            'receiver_name' => $parcel->receiver_name,
            'receiver_contact' => $parcel->receiver_contact,
            'delivery_address' => $parcel->delivery_address,
            'delivery_city' => $parcel->delivery_city,
            'area' => $parcel->area?->name,
            'status' => $parcel->status,
            'rider' => $parcel->assignment?->rider?->name,
        ];
    }
}
