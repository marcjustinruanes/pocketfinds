<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Parcel extends Model
{
    protected $fillable = [
        'tracking_number', 'sender_name', 'receiver_name', 'receiver_contact',
        'delivery_address', 'delivery_city', 'area_id', 'status', 'received_at',
        'sorted_at', 'assigned_at', 'picked_up_at', 'delivered_at', 'issue_note',
    ];

    protected $casts = [
        'received_at' => 'datetime',
        'sorted_at' => 'datetime',
        'assigned_at' => 'datetime',
        'picked_up_at' => 'datetime',
        'delivered_at' => 'datetime',
    ];

    public function area() { return $this->belongsTo(Area::class); }
    public function assignment() { return $this->hasOne(ParcelAssignment::class); }
    public function events() { return $this->hasMany(ParcelEvent::class); }
}
