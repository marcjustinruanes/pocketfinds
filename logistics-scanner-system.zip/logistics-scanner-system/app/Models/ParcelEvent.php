<?php
namespace App\Models;
use Illuminate\Database\Eloquent\Model;
class ParcelEvent extends Model
{
    protected $fillable = ['parcel_id', 'status', 'note', 'created_by'];
    public function parcel() { return $this->belongsTo(Parcel::class); }
}
