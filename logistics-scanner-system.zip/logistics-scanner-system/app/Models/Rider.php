<?php
namespace App\Models;
use Illuminate\Database\Eloquent\Model;
class Rider extends Model
{
    protected $fillable = ['name', 'contact', 'area_id', 'active'];
    protected $casts = ['active' => 'boolean'];
    public function area() { return $this->belongsTo(Area::class); }
}
