<?php
namespace App\Models;
use Illuminate\Database\Eloquent\Model;
class ParcelAssignment extends Model
{
    protected $fillable = ['parcel_id', 'rider_id', 'assigned_by', 'assigned_at'];
    protected $casts = ['assigned_at' => 'datetime'];
    public function rider() { return $this->belongsTo(Rider::class); }
    public function parcel() { return $this->belongsTo(Parcel::class); }
}
