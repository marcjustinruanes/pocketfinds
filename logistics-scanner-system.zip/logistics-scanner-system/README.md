# Logistics Scanner System - Laravel

A focused Laravel web implementation for a Sorting Center / Logistics workflow.

## What is included

- Logistics login/session
- Parcel dashboard
- Receive parcel
- Phone-browser barcode/QR scanner
- Laptop/desktop webcam scanner
- USB barcode scanner support (keyboard-style input)
- Automatic parcel lookup
- Delivery-area determination
- Sorting workflow
- Area-based rider assignment
- Rider list is seeded only; rider/courier registration is intentionally excluded
- Status history and delivery history
- Issues page and messages placeholder
- Seeded demo parcel, areas, and riders

## Important scanner design

The phone does NOT need the Flutter app. Open the Laravel scan page in the phone browser and allow camera access. The phone acts as a wireless scanner: it reads the barcode/QR value and sends the tracking number to Laravel.

The same scan page also accepts a USB barcode scanner because USB scanners normally behave like a keyboard and type into the tracking-number input.

## Requirements

- PHP 8.2+
- Composer
- MySQL 8+
- Laravel 11/12 compatible environment
- A browser with camera support for phone/webcam scanning

## Install into a fresh Laravel project

1. Create a fresh Laravel project:

   composer create-project laravel/laravel logistics-system

2. Copy the contents of this ZIP into the Laravel project and allow files to overwrite when appropriate.

3. Configure `.env` for MySQL.

4. Run:

   php artisan migrate --seed

5. Start Laravel so other devices on the same Wi-Fi can reach it:

   php artisan serve --host=0.0.0.0 --port=8000

6. On the computer open:

   http://127.0.0.1:8000/login

7. On the phone, use the computer's local IP, for example:

   http://192.168.1.10:8000/login

   Replace `192.168.1.10` with the computer's actual IPv4 address.

## Demo account

Email: logistics@example.com
Password: password

## Demo tracking numbers

- TRK-2026-0001 - Santa Cruz, Laguna - Area A
- TRK-2026-0002 - Pagsanjan, Laguna - Area B
- TRK-2026-0003 - Los Baños, Laguna - Area C

## Camera notes

Camera permissions are required. For local development, use localhost on the computer. For a phone connected to a PC-hosted Laravel server, browser camera behavior may require HTTPS depending on the browser/network setup. For a classroom demo, an HTTPS tunnel or local HTTPS setup can be used if the phone browser refuses camera access.

## Workflow

Delivery Request -> Receive -> Scan -> Area Detection -> Sort -> Assign Correct Rider -> Rider Assignment Visible -> Pick Up -> In Transit -> Delivered/Failed.

The current package focuses on the Logistics/Sorting Center side. Rider registration and approval are deliberately not included.
