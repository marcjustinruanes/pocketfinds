# Middleware setup

For Laravel 11/12, add the alias below to `bootstrap/app.php` inside the `withMiddleware` callback:

```php
->withMiddleware(function (Middleware $middleware) {
    $middleware->alias([
        'logistics.auth' => \App\Http\Middleware\LogisticsAuth::class,
    ]);
})
```

If your project already has a middleware alias array, just add the `logistics.auth` entry instead of replacing anything.
